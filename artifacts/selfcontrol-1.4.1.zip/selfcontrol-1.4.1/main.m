//
//  main.m
//  SelfControl
//
//  Created by Charlie Stigler on 1/28/09.
//  Copyright Harvard-Westlake Student 2009. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, char *argv[])
{
  return NSApplicationMain(argc,  (const char **) argv);
}
