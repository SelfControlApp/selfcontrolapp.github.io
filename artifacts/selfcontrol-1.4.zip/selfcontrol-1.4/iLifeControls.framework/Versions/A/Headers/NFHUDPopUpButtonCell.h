//
//  NFHUDPopUpButtonCell.h
//  iLife HUD PopUpButton
//
//  Created by Sean Patrick O'Brien on 9/23/06.
//  Copyright 2006 Sean Patrick O'Brien. All rights reserved.
//
//

#import <Cocoa/Cocoa.h>


@interface NFHUDPopUpButtonCell : NSPopUpButtonCell {

}

@end
